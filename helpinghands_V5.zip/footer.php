<footer class="footer">
  <div class="container">
	<span class="text-muted">© HelpingHands 2019</span>
  </div>
</footer>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>
